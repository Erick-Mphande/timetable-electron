const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// Load the database
let database;
try {
    database = JSON.parse(fs.readFileSync('database.json', 'utf8'));
} catch (err) {
    console.error('Error reading database file:', err);
    database = { students: {}, lecturers: {}, timetables: {} }; // Initialize if file doesn't exist
}

// Function to save the database
const saveDatabase = () => {
    fs.writeFileSync('database.json', JSON.stringify(database, null, 2));
};

// API route for student registration
app.post('/register/student', (req, res) => {
    const { name, password, course } = req.body;

    if (!name || !password || !course) {
        return res.status(400).send('Missing required fields');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    if (database.students && database.students[lowerCaseName]) {
        return res.status(400).send('Student already exists');
    }

    // Add student to the database
    database.students = database.students || {};  // Ensure students object exists
    database.students[lowerCaseName] = {
        password: password,
        course: course,
        role: 'student',
        timetable: []
    };

    saveDatabase();
    res.status(200).send('Student registered successfully');
});

// API route for lecturer registration
app.post('/register/lecturer', (req, res) => {
    const { name, password } = req.body;

    if (!name || !password) {
        return res.status(400).send('Missing required fields');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    if (database.lecturers && database.lecturers[lowerCaseName]) {
        return res.status(400).send('Lecturer already exists');
    }

    // Add lecturer to the database
    database.lecturers = database.lecturers || {};  // Ensure lecturers object exists
    database.lecturers[lowerCaseName] = {
        password: password,
        role: 'lecturer',
        batches: []
    };

    saveDatabase();
    res.status(200).send('Lecturer registered successfully');
});

// API route for login
app.post('/login', (req, res) => {
    const { name, password } = req.body;

    if (!name || !password) {
        return res.status(400).send('Missing username or password');
    }

    const lowerCaseName = name.toLowerCase(); // Convert name to lower case for consistent comparison

    // Check if user is an admin
    if (database.users && database.users[lowerCaseName] && database.users[lowerCaseName].password === password) {
        return res.json({ role: 'admin' });
    }

    // Check if user is a student
    if (database.students && database.students[lowerCaseName] && database.students[lowerCaseName].password === password) {
        return res.json({ role: 'student' });
    }

    // Check if user is a lecturer
    if (database.lecturers && database.lecturers[lowerCaseName] && database.lecturers[lowerCaseName].password === password) {
        return res.json({ role: 'lecturer' });
    }

    return res.status(401).send('Invalid credentials');
});

// API route for viewing users
app.get('/admin/viewUsers', (req, res) => {
    res.json({
        students: Object.keys(database.students || {}).map(username => ({
            username: username,
            course: database.students[username].course
        })),
        lecturers: Object.keys(database.lecturers || {}).map(username => ({
            username: username,
            batches: database.lecturers[username].batches
        }))
    });
});

// API route for deleting a student
app.delete('/admin/deleteStudent', (req, res) => {
    const { name } = req.body;

    if (!name || !database.students[name.toLowerCase()]) {
        return res.status(400).send('Student not found');
    }

    delete database.students[name.toLowerCase()];
    saveDatabase();
    res.send(`Student ${name} deleted successfully`);
});

// API route for deleting a lecturer
app.delete('/admin/deleteLecturer', (req, res) => {
    const { name } = req.body;

    if (!name || !database.lecturers[name.toLowerCase()]) {
        return res.status(400).send('Lecturer not found');
    }

    delete database.lecturers[name.toLowerCase()];
    saveDatabase();
    res.send(`Lecturer ${name} deleted successfully`);
});

// API route for creating the timetable
app.post('/admin/createTimetable', (req, res) => {
    const { program, year, semester, entries } = req.body; // Include year and semester

    // Check if program, year, or entries are valid
    if (!program || !year || !semester || !entries || !Array.isArray(entries)) {
        return res.status(400).send('Invalid program, year, or entries');
    }

    // Ensure the timetable data structure exists for the program
    database.timetables = database.timetables || {};
    database.timetables[program] = database.timetables[program] || {}; // Initialize program if not present

    // Create or update the timetable for the specified program, year, and semester
    database.timetables[program][`${year}-${semester}`] = entries; // Use year-semester as the key

    saveDatabase();
    res.send(`Timetable created successfully for ${program}, Year ${year}, Semester ${semester}`);
});

// API route for getting a program's timetable
app.get('/timetable/:program/:year/:semester', (req, res) => {
    const { program, year, semester } = req.params;

    console.log('Fetching timetable for program:', program, 'Year:', year, 'Semester:', semester); // Debugging log

    if (!database.timetables || !database.timetables[program] || !database.timetables[program][`${year}-${semester}`]) {
        return res.status(404).send('Timetable not found for program: ' + program);
    }

    const timetable = database.timetables[program][`${year}-${semester}`];
    console.log('Retrieved timetable:', timetable); // Log the retrieved timetable
    res.json(timetable);
});

// API route for viewing lecturers (only names)
app.get('/admin/viewLecturers', (req, res) => {
    const lecturersList = Object.keys(database.lecturers || {}).map(username => ({
        username: username
        // No longer including batches
    }));
    res.json(lecturersList);
});

// Starting the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
